Frozen historical recovery set. Not a current installer or runtime.
Original helper, recovery and artifact hashes are preserved, not amended.
The probe and wrapper are restored from Git f414108f235df590734d2acb5061b6adec60f7ea.
No credentials, private runtime journal, human events or production database are included.
Those retained originals remain required; unknown states stay unresolved.
Extraction is for inspection and isolated tests. Applying recovery or installing historical code
requires separately authorized review of machine identity, original journal, ACL and task state.
Do not reactivate fastapic or retired decision writers from a historical artifact.
